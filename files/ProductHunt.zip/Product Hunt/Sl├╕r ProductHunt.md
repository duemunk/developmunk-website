# Links
- developmunk.dk/slor
- https://itunes.apple.com/app/id1253636766
# Name
Slør
# Tagline
Edit Portrait Mode Photos in iOS 11.
# Topics 
Photography, iPhone, Tech
# Makers
@tobiasdm – Tobias Due Munk
# Media
- macstories.net article when it's up
# Social links
- twitter.com/tobiasdm
- https://www.instagram.com/slor_app/ (add photos)

# Description
...

› Adjust background blur.
› Adjust focus point.
› Higher quality.

Combine Effects
› Lens Blur. Add a radial effect for blurring everything around the subject additionally for dramatic effect.
› Tilt. Adjust the focal plane by tilting it, just like a tilt-shift lens does on a DSLR.
› Depth Map. Preview depth information with a quick 3D Touch to quickly see how radial and tilt affects it.

# Maker comment
I'm an avid photographer that instantly fell in love with the Portrait Mode effect on the iPhone 7 Plus, so the phone replaced my DSLR as my weapon of choice.

I really like Portrait Modes live preview and high quality effect, but the lack of editing capabilities left me wanting more. When the new depth APIs were announced at WWDC, I instantly knew that I had to make that editing app. Being an aspiring indie app developer, I cleared most of my schedule from WWDC to iOS 11's release in September.

(I'm fascinated by how computational photography makes the iPhone an even more competitive camera for professionals as well as consumers. With the improvements to the developer APIs in iOS 11 I can finally help push the photos to a higher quality and provides creatives with an even higher degree of freedom.)