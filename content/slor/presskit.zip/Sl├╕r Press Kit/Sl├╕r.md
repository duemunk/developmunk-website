# Slør
## Edit Depth Effect Photos.

Slør gives dual camera iPhones super powers by using the depth information available in Portrait Mode photos in iOS 11. It lets you tweak the background blur and adjust what's in focus. The resulting photos have high quality out of focus blurs.

### Features
- Change Aperture: Drag the slider to adjust the amount of out-of-focus blur.
- Change Focus Point: Tap anywhere on the photo to select what should be in focus.
- Combine Effects: Use tilt-shift and radial lens along with Portrait Mode blur for a combined beautiful effect.
- Depth Map: Preview depth information with a quick 3D Touch to quickly see how radial and tilt affects it.
- Deep iOS Integration: Photo Editing Extension to edit photos directly from Photos. Open original or edited photo and save as duplicate or a non-destructive modification.
- Saved Edits: All parameters for edits in Slør are stored in Photos. Enables quick tweaks of previously edited photos.
- High Quality: Slør uses the same algorithms as Apple's state of the art Portrait Mode, tweaked for an even higher quality output.
- Accessibility: Adaptable font sizes with Dynamic Type, Smart Invert, and Voice Over support.

### Creator
Slør is designed and developed by Tobias Due Munk from Copenhagen, Denmark. Tobias is an avid photographer that instantly fell in love with the Portrait Mode effect on the iPhone 7 Plus, so the phone replaced my DSLR as my weapon of choice.

### Quotes
"I really like Portrait Modes live preview and high quality effect, but the lack of editing capabilities left me wanting more. When the new depth APIs were announced at WWDC this year, I instantly knew that I had to make that editing app. I cleared most of my schedule from WWDC to iOS 11's release in September." 
– Tobias Due Munk.

"I'm fascinated by how computational photography makes the iPhone an even more competitive camera for professionals as well as consumers. With the improvements to the developer APIs in iOS 11 I can finally help push the photos to a higher quality and provides creatives with an even higher degree of freedom." 
– Tobias Due Munk

### Misc.
- The app is realised along with iOS 11, likely September 15 or 22.
- The app will cost $3/€4 up front and contains no in-app-purchases.
- The app works on iOS 11 for all iPhones and iPads.
- Currently only the iPhone 7 Plus has a dual camera and can take Portrait Mode photos which use the Depth Effect. Most of new iPhones announced in September will likely also feature a dual camera.
- App Store Category: Photo & Video.
- Available in English, Spanish, German, French, German, Norwegian, Swedish, and Danish.

### Links
[App Store](https://itunes.apple.com/app/id1253636766)
[Press Kit](https://developmunk.dk/slor/presskit.zip)
[Promo Website](https://developmunk.dk/slor)
[Developer Website](https://developmunk.dk)

## iTunes Description
...